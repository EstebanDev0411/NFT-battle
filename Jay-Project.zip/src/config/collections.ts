export const userCollection = "users";  
export const leaderboardCollection = "leaderboard";